function onCreate()
	makeLuaSprite('stage', 'blank_space', -2500, -1000);
	addLuaSprite('stage', false);
	scaleObject('stage', 1.4, 1.4);

	makeAnimatedLuaSprite('gff', 'flying_gf', -1300, 700);
	addAnimationByPrefix('gff', 'loop', 'floating', 24, true);
	scaleObject('gff', 1, 1);
	addLuaSprite('gff', false);

	function onSongStart()
		doTweenX('gfTweenX', 'gff', 1300, 160, 'cubeInOut')
	end
end